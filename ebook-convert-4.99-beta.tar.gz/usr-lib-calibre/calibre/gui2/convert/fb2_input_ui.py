# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/build/calibre-DOR9qX/calibre-4.99.4+dfsg+really4.12.0/src/calibre/gui2/convert/fb2_input.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(400, 300)
        self.gridLayout = QtWidgets.QGridLayout(Form)
        self.gridLayout.setObjectName("gridLayout")
        spacerItem = QtWidgets.QSpacerItem(20, 213, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 1, 0, 1, 1)
        self.opt_no_inline_fb2_toc = QtWidgets.QCheckBox(Form)
        self.opt_no_inline_fb2_toc.setObjectName("opt_no_inline_fb2_toc")
        self.gridLayout.addWidget(self.opt_no_inline_fb2_toc, 0, 0, 1, 1)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):

        Form.setWindowTitle(_("Form"))
        self.opt_no_inline_fb2_toc.setText(_("Do not insert a &Table of Contents at the beginning of the book."))
