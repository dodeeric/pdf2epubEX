# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/build/calibre-DOR9qX/calibre-4.99.4+dfsg+really4.12.0/src/calibre/gui2/convert/rtf_input.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(518, 353)
        self.verticalLayout_3 = QtWidgets.QVBoxLayout(Form)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.opt_ignore_wmf = QtWidgets.QCheckBox(Form)
        self.opt_ignore_wmf.setObjectName("opt_ignore_wmf")
        self.verticalLayout_3.addWidget(self.opt_ignore_wmf)
        spacerItem = QtWidgets.QSpacerItem(20, 213, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):

        Form.setWindowTitle(_("Form"))
        self.opt_ignore_wmf.setText(_("Ignore &WMF images in the RTF file"))
