# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/build/calibre-DOR9qX/calibre-4.99.4+dfsg+really4.12.0/src/calibre/gui2/preferences/columns.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(504, 399)
        self.gridLayout = QtWidgets.QGridLayout(Form)
        self.gridLayout.setObjectName("gridLayout")
        self.label = QtWidgets.QLabel(Form)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 2)
        self.opt_columns = QtWidgets.QTableWidget(Form)
        self.opt_columns.setAlternatingRowColors(True)
        self.opt_columns.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.opt_columns.setObjectName("opt_columns")
        self.opt_columns.setColumnCount(0)
        self.opt_columns.setRowCount(0)
        self.gridLayout.addWidget(self.opt_columns, 1, 0, 1, 1)
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.column_up = QtWidgets.QToolButton(Form)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(I("arrow-up.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.column_up.setIcon(icon)
        self.column_up.setIconSize(QtCore.QSize(32, 32))
        self.column_up.setObjectName("column_up")
        self.verticalLayout_3.addWidget(self.column_up)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem)
        self.del_custcol_button = QtWidgets.QToolButton(Form)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(I("minus.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.del_custcol_button.setIcon(icon1)
        self.del_custcol_button.setIconSize(QtCore.QSize(32, 32))
        self.del_custcol_button.setObjectName("del_custcol_button")
        self.verticalLayout_3.addWidget(self.del_custcol_button)
        spacerItem1 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem1)
        self.add_custcol_button = QtWidgets.QToolButton(Form)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(I("plus.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.add_custcol_button.setIcon(icon2)
        self.add_custcol_button.setIconSize(QtCore.QSize(32, 32))
        self.add_custcol_button.setObjectName("add_custcol_button")
        self.verticalLayout_3.addWidget(self.add_custcol_button)
        spacerItem2 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem2)
        self.edit_custcol_button = QtWidgets.QToolButton(Form)
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap(I("edit_input.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.edit_custcol_button.setIcon(icon3)
        self.edit_custcol_button.setIconSize(QtCore.QSize(32, 32))
        self.edit_custcol_button.setObjectName("edit_custcol_button")
        self.verticalLayout_3.addWidget(self.edit_custcol_button)
        spacerItem3 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem3)
        self.column_down = QtWidgets.QToolButton(Form)
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap(I("arrow-down.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.column_down.setIcon(icon4)
        self.column_down.setIconSize(QtCore.QSize(32, 32))
        self.column_down.setObjectName("column_down")
        self.verticalLayout_3.addWidget(self.column_down)
        self.gridLayout.addLayout(self.verticalLayout_3, 1, 1, 1, 1)
        self.add_col_button = QtWidgets.QPushButton(Form)
        self.add_col_button.setIcon(icon2)
        self.add_col_button.setObjectName("add_col_button")
        self.gridLayout.addWidget(self.add_col_button, 2, 0, 1, 2)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):

        Form.setWindowTitle(_("Form"))
        self.label.setText(_("Here you can re-arrange the layout of the columns in the calibre library book list. You can hide columns by unchecking them. You can also create your own, custom columns."))
        self.column_up.setToolTip(_("Move column up"))
        self.column_up.setText(_("..."))
        self.del_custcol_button.setToolTip(_("Remove a user-defined column"))
        self.del_custcol_button.setText(_("..."))
        self.add_custcol_button.setToolTip(_("Add a user-defined column"))
        self.add_custcol_button.setText(_("..."))
        self.edit_custcol_button.setToolTip(_("Edit settings of a user-defined column"))
        self.edit_custcol_button.setText(_("..."))
        self.column_down.setToolTip(_("Move column down"))
        self.column_down.setText(_("..."))
        self.add_col_button.setText(_("Add &custom column"))

