# vim:fileencoding=utf-8

from time import monotonic
monotonic
